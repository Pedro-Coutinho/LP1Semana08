﻿namespace ClassVsStruct
{
    public struct PlayerStruct
    {
        public float Health { get; set; }
        public float Armour { get; set; }
    }
}
