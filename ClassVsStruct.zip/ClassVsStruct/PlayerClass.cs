﻿namespace ClassVsStruct
{
    public class PlayerClass
    {
        public float Health { get; set; }
        public float Armour { get; set; }
    }
}
